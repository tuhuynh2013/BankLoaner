package com.example.tuhuynh.myapplication.connecthandler;

public class URLs {

    private static final String ROOT_URL = "http://10.0.2.2/loginphp/Api.php?apicall=";
    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_LOGIN = ROOT_URL + "login";
    public static final String URL_GETBANKS = ROOT_URL + "getbanks";
    public static final String URL_USERPROFILE = ROOT_URL + "userprofile";
    public static final String URL_UPDATEUSERPROFILE = ROOT_URL + "updateuserprofile";

}
