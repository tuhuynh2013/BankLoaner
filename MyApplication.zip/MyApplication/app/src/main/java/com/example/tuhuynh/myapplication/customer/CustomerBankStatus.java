package com.example.tuhuynh.myapplication.customer;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.tuhuynh.myapplication.R;

public class CustomerBankStatus extends Fragment {

    public CustomerBankStatus() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frag_customer_bank_status, container, false);
    }

}
